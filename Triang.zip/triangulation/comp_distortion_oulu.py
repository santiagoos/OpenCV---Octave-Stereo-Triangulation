import sys, os
import numpy as np
from comp_distortion import *

def comp_distortion_oulu(xd,k):

    if k.size == 1:
    
        x = comp_distortion(xd,k)
    
    else:
    
        k1 = k[0]
        k2 = k[1]
        k3 = k[2]
        p1 = k[3]
        p2 = k[4]
        
        x = xd				# initial guess
    
        for kk in range(1,20):
                  
            r_2 = (np.power(x,2)).sum(axis=0)

	    k_radial = 1 + k1 * r_2 + k2 * np.power(r_2,2) + k3 * np.power(r_2,3)

            delta_x = np.array([(2 * p1 * np.multiply(x[0,],x[1,]) + p2 * (r_2 + 2 * np.power(x[0,],2))),(p1 * (r_2 + 2 * np.power(x[1,],2)) + 2 * p2 * np.multiply(x[0,],x[1,]))])

	    x = np.divide((xd - delta_x),(np.ones((2,1),float))*k_radial)

    return x
    
    
