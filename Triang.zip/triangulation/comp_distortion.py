import sys, os
import numpy as np
from comp_distortion_oulu import *

def comp_distortion(x_dist,k2):

    two, N = x_dist.shape

    if two != 2: 
       print('ERROR : The dimension of the points should be 2xN')
    
    if k2.size > 1:
    
        x_comp  = comp_distortion_oulu(x_dist,k2)
    
    else:

        radius_2 = radius_2 = np.power(x_dist[0,],2) + np.power(x_dist[1,],2)
        #print('R2', radius_2)

        radial_distortion = 1 + np.multiply(np.ones((2,1),float),np.multiply(k2,radius_2))
        #print('Rd', radius_2)

        radius_2_comp = np.divide((np.power(x_dist[0,],2) + np.power(x_dist[1,],2)),radial_distortion[0,])
        #print('Rdc', radius_2_comp)

        radial_distortion = 1 + np.multiply(np.ones((2,1),float),np.multiply(k2,radius_2_comp))
        #print('Rd', radial_distortion)

        x_comp = np.multiply(x_dist,np.power(radial_distortion,-1))
        #print('xc', x_comp)

    return x_comp

