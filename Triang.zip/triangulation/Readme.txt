Para ejecutar en python la funcion stereo_triangulation se debe:

1. Cargar con anterioridad el archivo .mat (Calib_Results_stereo.mat
) correspondiente a la calibracion estereo con ayuda de la libreria scipy y numpy
 
- Una vez cargado el archivo se discriminan las variables:

om = mat['om']
T = mat['T']

fc_left = mat['fc_left']
cc_left = mat['cc_left']
kc_left = mat['kc_left']
alpha_c_left = mat['alpha_c_left']

fc_right = mat['fc_right']
cc_right = mat['cc_right']
kc_right = mat['kc_right']
alpha_c_right = mat['alpha_c_right']

2. Ya se puede ejecutar la funcion de triangulacion de la siguiente manera:
XL,XR = stereo_triangulation(xL,xR,om,T,fc_left,cc_left,kc_left,alpha_c_left,fc_right,cc_right,kc_right,alpha_c_right)

- Donde xL (Cam izquierda) y xR (Cam derecha) son vectores de 1x2 con los valores de (u,v) para cada una de las camaras.

