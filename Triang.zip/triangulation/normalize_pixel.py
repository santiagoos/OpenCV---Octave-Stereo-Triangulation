import sys, os
import numpy as np
from comp_distortion_oulu import *

def normalize_pixel(x_kk,fc,cc,kc,alpha_c = 0):

# First: Subtract principal point, and divide by the focal length:
    x_distort = np.array([(np.divide((x_kk[0,] - cc[0]),fc[0])),(np.divide((x_kk[1,] - cc[1]),fc[1]))])
    
# Second: undo skew
    x_distort[0,] = x_distort[0,] - np.multiply(alpha_c,x_distort[1,])

    if np.linalg.norm(kc) != 0:
	# Third: Compensate for lens distortio:
        xn = comp_distortion_oulu(x_distort,kc)

    else:

        xn = x_distort

    return xn


