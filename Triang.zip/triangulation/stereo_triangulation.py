import sys, os
import numpy as np
from normalize_pixel import *
import cv2
from fractions import Fraction

def stereo_triangulation(xL,xR,om,T,fc_left,cc_left,kc_left,alpha_c_left,fc_right,cc_right,kc_right,alpha_c_right):

#parameters of the left and right cameras
    xt = normalize_pixel(xL,fc_left,cc_left,kc_left,alpha_c_left)
 #   print 'xt1\n',xt
    xtt = normalize_pixel(xR,fc_right,cc_right,kc_right,alpha_c_right)
  #  print 'xt1\n',xt

 #Extend the normalized projections in homogeneous coordinates
    xt = np.concatenate((xt,np.ones((1,xt.shape[1]),float)), axis=0) #3*1
  #  print 'xt\n',xt
    xtt = np.concatenate((xtt,np.ones((1,xtt.shape[1]),float)), axis=0) #3*1
   # print 'xtt\n',xtt

#Number of points:
    N = xt.shape[1]

#Rotation matrix corresponding to the rigid motion between left and right cameras:
    Ra = cv2.Rodrigues(om)
    R = Ra[0] #3*3
  #  print 'R\n',R
        
#Triangulation of the rays in 3D space:

    u = np.dot(R,xt) #3*1
  #  print 'u\n',u
    T_vect = np.tile(T, (1,N)) #3*1 
  #  print 'T_vect\n',T_vect
    u = np.squeeze(np.asarray(u))

    xt1 = np.squeeze(np.asarray(xt))
 #   print 'xt1\n',xt1
    xtt1 = np.squeeze(np.asarray(xtt))
 #   print 'xtt1\n',xtt1

    n_xt2 = np.dot(xt1,xt1) #Escalar
 #   print 'n_xt\n',n_xt2
    n_xtt2 = np.dot(xtt1,xtt1) #Escalar
 #   print 'n_xt\n',n_xtt2

    DD = np.multiply(n_xt2,n_xtt2) - np.power(np.dot(u,xtt1),2)
 #   print 'DD\n',DD

    dot_uT = np.dot(u,T_vect)
 #   print 'dot_uT\n',dot_uT
    dot_xttT = np.dot(xtt1,T_vect)
 #   print 'dot_xttT\n',dot_xttT
    dot_xttu = np.dot(u,xtt1)
 #   print 'dot_xttu\n',dot_xttu

    NN1 = np.multiply(dot_xttu,dot_xttT) - np.multiply(n_xtt2,dot_uT)
 #   print 'NN1\n',NN1
    NN2 = np.multiply(n_xt2,dot_xttT) - np.multiply(dot_uT,dot_xttu)
 #   print 'NN2\n',NN2

    Zt = np.divide(NN1,DD)
 #   print 'Zt\n',Zt
    Ztt = np.divide(NN2,DD)
  #  print 'Ztt\n',Ztt
    
    X1 = np.multiply(xt,np.tile(Zt, (3,1)))
#    print 'X1\n',X1
    X2 = np.dot(R.T,(np.multiply(xtt,(np.tile(Zt, (3,1)))) - T_vect))
 #   print 'X2\n',X2

#Left coordinates:
    XL = np.multiply(Fraction(1,2),(X1 + X2))

#Right coordinates:
    XR = np.dot(R,XL) + T_vect

    return XL,XR

