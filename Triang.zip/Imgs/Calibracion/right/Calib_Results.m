% Intrinsic and Extrinsic Camera Parameters
%
% This script file can be directly executed under Matlab to recover the camera intrinsic and extrinsic parameters.
% IMPORTANT: This file contains neither the structure of the calibration objects nor the image coordinates of the calibration points.
%            All those complementary variables are saved in the complete matlab data file Calib_Results.mat.
% For more information regarding the calibration model visit http://www.vision.caltech.edu/bouguetj/calib_doc/


%-- Focal length:
fc = [ 1424.850906665092680 ; 1426.200174660231141 ];

%-- Principal point:
cc = [ 999.171806188513983 ; 594.244436933056363 ];

%-- Skew coefficient:
alpha_c = 0.000000000000000;

%-- Distortion coefficients:
kc = [ -0.009182745961178 ; -0.025885687839730 ; 0.008726082612363 ; -0.002017667508276 ; 0.000000000000000 ];

%-- Focal length uncertainty:
fc_error = [ 5.883549598359308 ; 5.804520440452104 ];

%-- Principal point uncertainty:
cc_error = [ 7.210361084030764 ; 8.071249393849017 ];

%-- Skew coefficient uncertainty:
alpha_c_error = 0.000000000000000;

%-- Distortion coefficients uncertainty:
kc_error = [ 0.020536389579207 ; 0.115345902056695 ; 0.001858161539931 ; 0.001935251392760 ; 0.000000000000000 ];

%-- Image size:
nx = 1920;
ny = 1080;


%-- Various other variables (may be ignored if you do not use the Matlab Calibration Toolbox):
%-- Those variables are used to control which intrinsic parameters should be optimized

n_ima = 13;						% Number of calibration images
est_fc = [ 1 ; 1 ];					% Estimation indicator of the two focal variables
est_aspect_ratio = 1;				% Estimation indicator of the aspect ratio fc(2)/fc(1)
center_optim = 1;					% Estimation indicator of the principal point
est_alpha = 0;						% Estimation indicator of the skew coefficient
est_dist = [ 1 ; 1 ; 1 ; 1 ; 0 ];	% Estimation indicator of the distortion coefficients


%-- Extrinsic parameters:
%-- The rotation (omc_kk) and the translation (Tc_kk) vectors for every calibration image and their uncertainties

%-- Image #1:
omc_1 = [ 1.98249 ; 2.11261 ; -0.403197 ];
Tc_1  = [ -152.668 ; -234.174 ; 888.726 ];
omc_error_1 = [ 0.00416948 ; 0.00577215 ; 0.00945574 ];
Tc_error_1  = [ 4.58875 ; 5.03789 ; 4.06529 ];

%-- Image #2:
omc_2 = [ 1.96945 ; 2.08676 ; -0.420039 ];
Tc_2  = [ -160.947 ; -220.392 ; 882.247 ];
omc_error_2 = [ 0.00409082 ; 0.00567562 ; 0.00919122 ];
Tc_error_2  = [ 4.54347 ; 5.00249 ; 4.00169 ];

%-- Image #3:
omc_3 = [ 1.0051 ; 2.81473 ; -0.513452 ];
Tc_3  = [ -10.8386 ; -253.21 ; 891.274 ];
omc_error_3 = [ 0.00188048 ; 0.00678698 ; 0.00972098 ];
Tc_error_3  = [ 4.57799 ; 5.03626 ; 4.07643 ];

%-- Image #4:
omc_4 = [ 2.48399 ; 1.32727 ; -0.304359 ];
Tc_4  = [ -210.671 ; -78.0175 ; 832.287 ];
omc_error_4 = [ 0.00570287 ; 0.00396401 ; 0.00890445 ];
Tc_error_4  = [ 4.24748 ; 4.7162 ; 3.71446 ];

%-- Image #5:
omc_5 = [ -2.03552 ; -2.12845 ; -0.182561 ];
Tc_5  = [ -192.799 ; -197.533 ; 666.407 ];
omc_error_5 = [ 0.00464625 ; 0.00466356 ; 0.00939478 ];
Tc_error_5  = [ 3.45512 ; 3.85716 ; 3.42258 ];

%-- Image #6:
omc_6 = [ -2.05539 ; -2.18888 ; -0.0565844 ];
Tc_6  = [ -207.212 ; -170.996 ; 687.697 ];
omc_error_6 = [ 0.00475039 ; 0.00468731 ; 0.00992079 ];
Tc_error_6  = [ 3.52584 ; 3.96749 ; 3.42645 ];

%-- Image #7:
omc_7 = [ 1.62299 ; 1.71957 ; -0.835825 ];
Tc_7  = [ -178.991 ; -100.065 ; 811.047 ];
omc_error_7 = [ 0.00368555 ; 0.00546969 ; 0.00641836 ];
Tc_error_7  = [ 4.11727 ; 4.61589 ; 3.11225 ];

%-- Image #8:
omc_8 = [ 1.61325 ; 1.76891 ; -0.837218 ];
Tc_8  = [ -207.207 ; -108.508 ; 824.793 ];
omc_error_8 = [ 0.00345608 ; 0.0055858 ; 0.00660468 ];
Tc_error_8  = [ 4.18937 ; 4.72325 ; 3.25682 ];

%-- Image #9:
omc_9 = [ 1.6066 ; 1.88575 ; 0.212205 ];
Tc_9  = [ -174.43 ; -202.845 ; 656.136 ];
omc_error_9 = [ 0.00451006 ; 0.00464515 ; 0.00666899 ];
Tc_error_9  = [ 3.38927 ; 3.76186 ; 3.39912 ];

%-- Image #10:
omc_10 = [ 1.61713 ; 1.88874 ; 0.221424 ];
Tc_10  = [ -174.074 ; -201.532 ; 652.701 ];
omc_error_10 = [ 0.00453093 ; 0.00462693 ; 0.00668651 ];
Tc_error_10  = [ 3.37207 ; 3.74275 ; 3.38745 ];

%-- Image #11:
omc_11 = [ -2.0774 ; -1.96877 ; 0.961681 ];
Tc_11  = [ -187.417 ; -155.033 ; 838.941 ];
omc_error_11 = [ 0.00585797 ; 0.00295755 ; 0.00827308 ];
Tc_error_11  = [ 4.30937 ; 4.7909 ; 3.36457 ];

%-- Image #12:
omc_12 = [ -2.04358 ; -1.94919 ; 0.979052 ];
Tc_12  = [ -173.949 ; -151.519 ; 834.456 ];
omc_error_12 = [ 0.00580172 ; 0.00299005 ; 0.00810961 ];
Tc_error_12  = [ 4.27924 ; 4.75526 ; 3.30199 ];

%-- Image #13:
omc_13 = [ 1.92282 ; 2.12065 ; -0.305878 ];
Tc_13  = [ -204.554 ; -198.698 ; 697.73 ];
omc_error_13 = [ 0.0035777 ; 0.00531049 ; 0.00858088 ];
Tc_error_13  = [ 3.58605 ; 3.99893 ; 3.40721 ];

