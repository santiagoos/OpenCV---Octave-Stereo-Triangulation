% Intrinsic and Extrinsic Camera Parameters
%
% This script file can be directly executed under Matlab to recover the camera intrinsic and extrinsic parameters.
% IMPORTANT: This file contains neither the structure of the calibration objects nor the image coordinates of the calibration points.
%            All those complementary variables are saved in the complete matlab data file Calib_Results.mat.
% For more information regarding the calibration model visit http://www.vision.caltech.edu/bouguetj/calib_doc/


%-- Focal length:
fc = [ 1380.320333860455094 ; 1382.270110645942168 ];

%-- Principal point:
cc = [ 961.929859198186250 ; 556.232296102264627 ];

%-- Skew coefficient:
alpha_c = 0.000000000000000;

%-- Distortion coefficients:
kc = [ 0.085153903833675 ; -0.307406610711894 ; 0.008510877442656 ; -0.000121199433044 ; 0.000000000000000 ];

%-- Focal length uncertainty:
fc_error = [ 5.656963412134474 ; 5.629664453843199 ];

%-- Principal point uncertainty:
cc_error = [ 6.922201968595060 ; 7.655099838693608 ];

%-- Skew coefficient uncertainty:
alpha_c_error = 0.000000000000000;

%-- Distortion coefficients uncertainty:
kc_error = [ 0.023062513323684 ; 0.145892573121004 ; 0.002109241587315 ; 0.002166454034738 ; 0.000000000000000 ];

%-- Image size:
nx = 1920;
ny = 1080;


%-- Various other variables (may be ignored if you do not use the Matlab Calibration Toolbox):
%-- Those variables are used to control which intrinsic parameters should be optimized

n_ima = 13;						% Number of calibration images
est_fc = [ 1 ; 1 ];					% Estimation indicator of the two focal variables
est_aspect_ratio = 1;				% Estimation indicator of the aspect ratio fc(2)/fc(1)
center_optim = 1;					% Estimation indicator of the principal point
est_alpha = 0;						% Estimation indicator of the skew coefficient
est_dist = [ 1 ; 1 ; 1 ; 1 ; 0 ];	% Estimation indicator of the distortion coefficients


%-- Extrinsic parameters:
%-- The rotation (omc_kk) and the translation (Tc_kk) vectors for every calibration image and their uncertainties

%-- Image #1:
omc_1 = [ 2.03702 ; 2.02541 ; -0.362516 ];
Tc_1  = [ -95.7632 ; -224.838 ; 882.623 ];
omc_error_1 = [ 0.00458191 ; 0.00515679 ; 0.00952373 ];
Tc_error_1  = [ 4.50968 ; 4.86785 ; 4.05751 ];

%-- Image #2:
omc_2 = [ 2.02576 ; 2.00728 ; -0.392383 ];
Tc_2  = [ -103.037 ; -210.723 ; 877.501 ];
omc_error_2 = [ 0.00447222 ; 0.00507147 ; 0.00930557 ];
Tc_error_2  = [ 4.47181 ; 4.83744 ; 3.98785 ];

%-- Image #3:
omc_3 = [ 1.08791 ; 2.74784 ; -0.502342 ];
Tc_3  = [ 44.4022 ; -251.885 ; 891.598 ];
omc_error_3 = [ 0.00230445 ; 0.00627954 ; 0.00976643 ];
Tc_error_3  = [ 4.53103 ; 4.9359 ; 4.03943 ];

%-- Image #4:
omc_4 = [ 2.52187 ; 1.23934 ; -0.261761 ];
Tc_4  = [ -141.843 ; -65.7584 ; 826.547 ];
omc_error_4 = [ 0.00597665 ; 0.0033101 ; 0.00914298 ];
Tc_error_4  = [ 4.17638 ; 4.53942 ; 3.69385 ];

%-- Image #5:
omc_5 = [ -2.11209 ; -2.08867 ; -0.228792 ];
Tc_5  = [ -124.145 ; -186.547 ; 660.55 ];
omc_error_5 = [ 0.00437124 ; 0.00480596 ; 0.00963461 ];
Tc_error_5  = [ 3.39771 ; 3.71096 ; 3.31772 ];

%-- Image #6:
omc_6 = [ -2.14943 ; -2.16504 ; -0.125924 ];
Tc_6  = [ -136.524 ; -159.384 ; 678.145 ];
omc_error_6 = [ 0.00447608 ; 0.00488444 ; 0.0103208 ];
Tc_error_6  = [ 3.45477 ; 3.80299 ; 3.3179 ];

%-- Image #7:
omc_7 = [ 1.68682 ; 1.64659 ; -0.824655 ];
Tc_7  = [ -110.639 ; -89.6688 ; 804.524 ];
omc_error_7 = [ 0.00422396 ; 0.00477017 ; 0.0066399 ];
Tc_error_7  = [ 4.0444 ; 4.43323 ; 3.01687 ];

%-- Image #8:
omc_8 = [ 1.67914 ; 1.69372 ; -0.821019 ];
Tc_8  = [ -139.532 ; -96.3688 ; 816.608 ];
omc_error_8 = [ 0.00398362 ; 0.0048644 ; 0.00681404 ];
Tc_error_8  = [ 4.10334 ; 4.52145 ; 3.13194 ];

%-- Image #9:
omc_9 = [ 1.64172 ; 1.80364 ; 0.224008 ];
Tc_9  = [ -104.483 ; -193.215 ; 650.59 ];
omc_error_9 = [ 0.00449428 ; 0.00413551 ; 0.00678561 ];
Tc_error_9  = [ 3.31945 ; 3.60087 ; 3.34199 ];

%-- Image #10:
omc_10 = [ 1.65258 ; 1.80357 ; 0.227115 ];
Tc_10  = [ -104.702 ; -191.663 ; 646.822 ];
omc_error_10 = [ 0.00450568 ; 0.00411544 ; 0.00680195 ];
Tc_error_10  = [ 3.30015 ; 3.58004 ; 3.32526 ];

%-- Image #11:
omc_11 = [ -2.1657 ; -1.91811 ; 0.918286 ];
Tc_11  = [ -123.023 ; -143.724 ; 831.037 ];
omc_error_11 = [ 0.00542023 ; 0.00294188 ; 0.00888707 ];
Tc_error_11  = [ 4.22931 ; 4.5869 ; 3.27009 ];

%-- Image #12:
omc_12 = [ -2.13008 ; -1.89615 ; 0.93 ];
Tc_12  = [ -109.663 ; -141.195 ; 828.37 ];
omc_error_12 = [ 0.00534527 ; 0.00297433 ; 0.00870992 ];
Tc_error_12  = [ 4.21159 ; 4.56522 ; 3.21908 ];

%-- Image #13:
omc_13 = [ 1.9747 ; 2.03188 ; -0.268643 ];
Tc_13  = [ -136.357 ; -186.752 ; 689.267 ];
omc_error_13 = [ 0.00402165 ; 0.00463826 ; 0.00855636 ];
Tc_error_13  = [ 3.50096 ; 3.80858 ; 3.32516 ];

